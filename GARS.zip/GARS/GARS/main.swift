//
//  main.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-26.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

let admins = ["govinda":"sharma", "arshdeep":"singh","foram":"dadhania"]

func showIntro(){
    print("\n\t\t\t\t\t\t*** Welcome to GARS ***\n\n\t\t\t\t\tGAVI ARSH AIR RESERVATION SYSTEM\n\n\n")
}

func promptInput(){
    print("\tPress A to enter as ADMIN\t\t\tPress U to enter as USER\n\n\n\t\t\t\t\t\t   Press X to EXIT")
}

//Method to print all the employees
func viewAllEmployees(){
    print("View all employees method")
//    let loadEmps = EmployeeDataHelper()
//    loadEmps.displayEmployees()
    (EmployeeDataHelper()).displayEmployees()
    adminSubRoutine()
}

func deleteEmployee(){
    print("Please enter the ID of the Employee you want to delete from the following:")
    print((EmployeeDataHelper()).displayEmployeeIds())
    let userId: Int = (Int)(readLine()!)!
    (EmployeeDataHelper()).deleteEmployeeWithId(empID: userId)
    print("User with \(userId) deleted.")
    sleep(200)
    adminSubRoutine()
}

func addEmployee(){
    print("Add employee method")
    adminSubRoutine()
}

func adminSubRoutine(){
    print("Welcome Admin:")
    print("Press 1: To view all Employees")
    print("Press 2: To delete an Employee")
    print("Press 3: To add an Employee")
    print("Press 4: Go Back")
    let adminInput: Int = (Int)(readLine()!)!
    switch adminInput {
    case 1:
        viewAllEmployees()
        break
    case 2:
        deleteEmployee()
        break
    case 3:
        addEmployee()
        break
    case 4:
        initialStep()
        break
    default:
        print("Default case")
    }
}

func viewAllFlights(){
    for (_,flight) in FlightDataHelper().flights.sorted(by: {$0.key < $1.key}) {
        flight.displayData()
    }
    userSubRoutine()
}
func viewAllFlightsForBooking(){
    for (_,flight) in FlightDataHelper().flights.sorted(by: {$0.key < $1.key}) {
        flight.displayData()
    }
}

func searchFlightForBooking(){
    print("Please Enter Flight ID:")
    let source: Int = (Int)(readLine()!)!
    for flight in FlightDataHelper().searchFlightWithId(source: source){
        print(flight.displayData())
    }
}

func searchFlight(){
    print("Please enter the source city:")
    let source: String = readLine()!
    for flight in FlightDataHelper().searchFlightWith(source: source){
        print(flight.displayData())
    }
    userSubRoutine()
}

func bookFlight(){
    var book =  Booking()
    print("Book Flight")
    viewAllFlightsForBooking()
    book.bookTicket()
}

func viewBookings(){
    print("View Bookings")
    userSubRoutine()
}

func userSubRoutine(){
    print("Welcome Passenger:")
    print("Press 1: To view all Flights")
    print("Press 2: To search a Flight")
    print("Press 3: To book a Flight")
    print("Press 4: To view the bookings")
    print("Press 5: Go Back")
    let userInput: Int = (Int)(readLine()!)!
    switch userInput {
    case 1:
        viewAllFlights()
        break
    case 2:
        searchFlight()
        break
    case 3:
        bookFlight()
        break
    case 4:
        viewBookings()
        break
    case 5:
        initialStep()
        break
    default:
        print("Default case")
    }
}

func verifyAdmin(){
    print("Press Y to continue or N to Go Back...")
    let cont: String = readLine()!
    if cont == "Y" || cont == "y" {
        print("\nPlease enter Username: ")
        let userName: String = readLine()!
        print("\nPlease enter your password: ")
        let password: String = readLine()!
        if admins[userName] == password{
            print("Login successful")
            adminSubRoutine()
        } else{
            print("Incorrect username/password")
            verifyAdmin()
            print("\n\n")
        }
    } else{
        initialStep()
    }
}

func initialStep(){
    var userInput: String
    promptInput()
    userInput = readLine()!
    if userInput.elementsEqual("A") || userInput.elementsEqual("a") {
        sleep(1)
        
        verifyAdmin()
    } else if userInput.elementsEqual("U") || userInput.elementsEqual("u") {
        userSubRoutine()
    } else if !((userInput.elementsEqual("x")) || (userInput.elementsEqual("X"))){
        initialStep()
    }
    print("\n\n\n\n\n")
}

showIntro()
initialStep()



//Uncomment the following code to enter the passenger details
//var psngr = Passenger()
//psngr.enterPassengerDetails()
//psngr.displayData()
