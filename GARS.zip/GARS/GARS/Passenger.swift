//
//  Passenger.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-25.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

class Passenger: BaseUser{
    var passportNumber: String
    var age: Int
    var physicallyChallenged: Bool
    
    override init() {
        self.passportNumber = ""
        self.age = 0
        self.physicallyChallenged = false
        super.init()
    }
    
    init(id: Int, name: String, email: String, mobile: String, address: String, gender: Gender, passportNumber: String, age: Int, physicallyChallenged: Bool) {
        self.passportNumber = passportNumber
        self.age = age
        self.physicallyChallenged = physicallyChallenged
        super.init(id: id, name: name, email: email, mobile: mobile, address: address, gender: gender)
    }
    
    func enterPassengerDetails(){
        super.addUser()
        print("Enter Passport Number: ")
        self.passportNumber = readLine()!
        print("Enter Age: ")
        self.age = (Int)(readLine()!)!
        print("Are you physically challenged?\n\tPress Y for YES\n\tPress N for NO")
        let chlngd: String = readLine()!
        if (chlngd.elementsEqual("Y")) || (chlngd.elementsEqual("y")) {
            self.physicallyChallenged = true
        } else if (chlngd.elementsEqual("N")) || (chlngd.elementsEqual("n")) {
            self.physicallyChallenged = false
        }
    }
    
    override func displayData() {
        print("Passenger details: ")
        super.displayData()
        print("Passport#: \(self.passportNumber)")
        print("Age: \(self.age)")
        print("Is physically challenged: \(self.physicallyChallenged)")
    }
}
