//
//  BaseUser.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-24.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

class BaseUser{
    var id: Int
    var name: String
    var email: String
    var mobile: String
    var address: String
    var gender: Gender
    
    init() {
        self.id = 0
        self.name = ""
        self.email = ""
        self.mobile = ""
        self.address = ""
        self.gender = Gender.Male
    }
    
    init(id: Int, name: String, email: String, mobile: String, address: String, gender: Gender){
        self.id = id
        self.name = name
        self.email = email
        self.mobile = mobile
        self.address = address
        self.gender = gender
    }
    
    func displayUserID(){
        print("ID: \(self.id)")
    }
    
    func displayData(){
        print("ID: \(self.id)")
        print("Name: \(self.name)")
        print("Gender: \(self.gender)")
        print("Email: \(self.email)")
        print("Mobile: \(self.mobile)")
        print("Address: \(self.address)")
    }
    
    func addUser(){
        print("Enter ID(numeric): ")
        self.id = (Int)(readLine()!)!
        print("Enter Name: ")
        self.name = readLine()!
        print("Enter Gender: ")
        print("Press :\n\tM for Male\n\tF for Female")
        let gend: String = readLine()!
        if (gend.elementsEqual("M")) || (gend.elementsEqual("m")){
            self.gender = Gender.Male
        } else if (gend.elementsEqual("F")) || (gend.elementsEqual("f")){
            self.gender = Gender.Female
        }
        print("Enter Email: ")
        self.email = readLine()!
        print("Enter Mobile: ")
        self.mobile = readLine()!
        print("Enter Address: ")
        self.address = readLine()!
    }
}
