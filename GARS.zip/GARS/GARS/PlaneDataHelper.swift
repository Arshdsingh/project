//
//  PlaneDataHelper.swift
//  plane
//
//  Created by Govinda Sharma on 2018-07-24.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation


class PlaneDataHelper{
    var planeList = [Int : Plane]()
    
    init(){
        self.loadPlanes()
    }
    
    func loadPlanes(){
        planeList = [:]
        
        let AirCanada = Plane(planeID: 101 , planeName: "Air Canada", planeCapacity: 300, planetype : "Boeing 747" )
        planeList[AirCanada.Id] = AirCanada
        
        let JetAirways = Plane(planeID: 102, planeName: "Jet Airways", planeCapacity: 400, planetype : "Bombardier CRJ900" )
        planeList[JetAirways.Id] = JetAirways
        
        let AirIndia = Plane(planeID: 103, planeName: "Air India", planeCapacity: 250, planetype : "Embraer 190" )
        planeList[AirIndia.Id] = AirIndia
        
        let BritishAirways = Plane(planeID: 104, planeName: "British Airways", planeCapacity: 290, planetype : "Airbus A380" )
        planeList[BritishAirways.Id] = BritishAirways
        
        let Lufthansa = Plane(planeID: 105, planeName: "Lufthansa", planeCapacity: 290, planetype : "Boeing 787" )
        planeList[Lufthansa.Id] = Lufthansa
    }
    
    func bookFlight() {
        
    }
    
    func displayPlane(){
        for (_, value) in self.planeList.sorted(by: { $0.key < $1.key} ){
            print(value.displayData())
        }
    }
}

