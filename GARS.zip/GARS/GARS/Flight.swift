//
//  Flight.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-27.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

class Flight{
    var id: Int
    var name: String
    var source: String
    var destination: String
    var plane: Plane
    var employee : Employee
    var baseFare : Double
    var bookedSeats: [String]
    
    init() {
        self.id = 0
        self.name = ""
        self.source = ""
        self.destination = ""
        self.plane = Plane()
        self.employee = Employee()
        self.baseFare = 0.0
        bookedSeats = [""]
    }
    
    init(id: Int, name: String, source: String, destination: String, plane: Plane, employee: Employee, baseFare: Double) {
        self.id = id
        self.name = name
        self.source = source
        self.destination = destination
        self.plane = plane
        self.employee = employee
        self.baseFare = baseFare
        self.bookedSeats = [""]
    }
    
    func displayData(){
        print("\tFlight Details:")
        print("\t\tID: \(self.id)")
        print("\t\tName: \(self.name)")
        print("\t\tSource: \(self.source)")
        print("\t\tDestination: \(self.destination)")
        print("\t\tPlane Type: \(self.plane.PlaneType)")
        print("\t\tChief Staff: \(self.employee.name)")
        print("\t\tBase Fare: \(self.baseFare.asCurrency)")
        print("\t\tBooked Seats:")
        for seat in bookedSeats {
            print("\t\t\t \(seat)")
        }
    }
}
