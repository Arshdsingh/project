//
//  FlightDataHelper.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-27.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation
class FlightDataHelper{
    var flights = [Int : Flight]()
    
    init() {
        self.loadFlights()
    }
    
    func loadFlights(){
        let flight1 = Flight.init(id: 101, name: "Air Canada", source: "Toronto", destination: "Delhi", plane: PlaneDataHelper().planeList[101]!, employee: EmployeeDataHelper().employees[101]!, baseFare: 600.0)
        flights[flight1.id] = flight1
        
        let flight2 = Flight.init(id: 102, name: "Air Canada", source: "Toronto", destination: "Paris", plane: PlaneDataHelper().planeList[102]!, employee: EmployeeDataHelper().employees[102]!, baseFare: 400.0)
        flights[flight2.id] = flight2
        
        let flight3 = Flight.init(id: 103, name: "Jet Airways", source: "Delhi", destination: "Paris", plane: PlaneDataHelper().planeList[103]!, employee: EmployeeDataHelper().employees[103]!, baseFare: 500.0)
        flights[flight3.id] = flight3
        
        let flight4 = Flight.init(id: 104, name: "Jet Airways", source: "Delhi", destination: "London", plane: PlaneDataHelper().planeList[104]!, employee: EmployeeDataHelper().employees[105]!, baseFare: 400.0)
        flights[flight4.id] = flight4
        
        let flight5 = Flight.init(id: 105, name: "Air India", source: "Chandigarh", destination: "Delhi", plane: PlaneDataHelper().planeList[105]!, employee: EmployeeDataHelper().employees[106]!, baseFare: 150.0)
        flights[flight5.id] = flight5
        
        let flight6 = Flight.init(id: 106, name: "Air India", source: "Chandigarh", destination: "Mumbai", plane: PlaneDataHelper().planeList[101]!, employee: EmployeeDataHelper().employees[101]!, baseFare: 170.0)
        flights[flight6.id] = flight6
        
        let flight7 = Flight.init(id: 107, name: "British Airways", source: "London", destination: "Mumbai", plane: PlaneDataHelper().planeList[102]!, employee: EmployeeDataHelper().employees[103]!, baseFare: 450.0)
        flights[flight7.id] = flight7
        
        let flight8 = Flight.init(id: 108, name: "British Airways", source: "London", destination: "Paris", plane: PlaneDataHelper().planeList[103]!, employee: EmployeeDataHelper().employees[104]!, baseFare: 430.0)
        flights[flight8.id] = flight8
        
        let flight9 = Flight.init(id: 109, name: "Lufthansa", source: "Paris", destination: "Toronto", plane: PlaneDataHelper().planeList[104]!, employee: EmployeeDataHelper().employees[105]!, baseFare: 410.0)
        flights[flight9.id] = flight9
        
        let flight10 = Flight.init(id: 110, name: "Lufthansa", source: "Paris", destination: "London", plane: PlaneDataHelper().planeList[105]!, employee: EmployeeDataHelper().employees[106]!, baseFare: 440.0)
        flights[flight10.id] = flight10
    }
    
    func searchFlightWith(source: String) -> [Flight] {
        var flight: [Flight] = [Flight]()
        for (_,flt) in flights {
            if flt.source == source{
                flight.append(flt)
            }
        }
        return flight
    }
    
    func searchFlight(flightID : Int) -> Flight?{
        if flights[flightID] != nil{
            return flights[flightID]! as Flight
        }
        else{
            print("Sorry..The product number you have entered is not available")
            return nil
        }
    }
    /*
    func searchFlightWithId(source: Int) -> [Flight] {
        var flight: [Flight] = [Flight]()
        for (_,fltid) in flights {
            if fltid.id == source {
                flight.append(fltid)
            }
        }
        return flight
    }
 */
}
