//
//  Booking.swift
//  GARS
//
//  Created by Arshdeep Singh on 2018-07-29.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

typealias bookTheFlight = (flightId : Int, flight : Flight)

class Booking: Flight {
    private var flightid : Int
    private var flightname : String
    private var bookTheFlights : [bookTheFlight]
    
    private var flightdatahelper = FlightDataHelper()
    
    override init() {
        self.flightid = 0
        self.flightname = ""
        self.bookTheFlights = []
        super.init()
    }
    
    var FlightID : Int{
        get { return self.flightid }
        set{ self.flightid = newValue}
    }
    var FlightName : String{
        get { return self.flightname }
        set{ self.flightname = newValue}
    
    }

    func bookTicket(){
        print("Please enter Flight Id : ")
        let selectedFlightID : Int = (Int)(readLine()!)!
        
        if flightdatahelper.searchFlight(flightID: selectedFlightID) != nil{
            self.FlightID = flightid
            self.FlightName = flightname
            
            //self.bookTheFlights += [(flightid : selectedFlightID,flight : )]
            
        }else{
            print("Sorry...")
        }
    }
    
}
